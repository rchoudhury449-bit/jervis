package com.rahul.assistant

import java.text.Normalizer

/**
 * Text ko saaf karne aur naam ko "awaaz ke hisaab se" match karne ke liye.
 *
 * Hindi recognizer naam Devanagari me deta hai ("राहुल") jabki contact me
 * "Rahul" likha hota hai. key() dono ko ek simple consonant-skeleton me badal deta hai
 * ("rl"), taaki dono match ho jaye.
 */
object Phonetic {

    private val ws = Regex("\\s+")

    private val dev: Map<Char, String> = mapOf(
        'क' to "k", 'ख' to "k", 'ग' to "g", 'घ' to "g", 'ङ' to "n",
        'च' to "c", 'छ' to "c", 'ज' to "j", 'झ' to "j", 'ञ' to "n",
        'ट' to "t", 'ठ' to "t", 'ड' to "d", 'ढ' to "d", 'ण' to "n",
        'त' to "t", 'थ' to "t", 'द' to "d", 'ध' to "d", 'न' to "n",
        'प' to "p", 'फ' to "p", 'ब' to "b", 'भ' to "b", 'म' to "m",
        'य' to "", 'र' to "r", 'ल' to "l", 'व' to "v",
        'श' to "s", 'ष' to "s", 'स' to "s", 'ह' to "",
        'ं' to "n", 'ँ' to "n",
        'अ' to "", 'आ' to "", 'इ' to "", 'ई' to "", 'उ' to "", 'ऊ' to "",
        'ऋ' to "r", 'ए' to "", 'ऐ' to "", 'ओ' to "", 'औ' to "", 'ऑ' to ""
    )

    fun nfc(s: String): String = Normalizer.normalize(s, Normalizer.Form.NFC)

    private fun isKept(c: Char): Boolean {
        if (c.isLetterOrDigit()) return true
        val t = Character.getType(c)
        return t == Character.NON_SPACING_MARK.toInt() ||
            t == Character.COMBINING_SPACING_MARK.toInt()
    }

    /** lowercase, punctuation hata ke, ek space se alag kiye hue shabd. */
    fun clean(text: String): String {
        val sb = StringBuilder()
        for (ch in nfc(text).lowercase()) {
            if (isKept(ch)) sb.append(ch) else sb.append(' ')
        }
        return sb.toString().trim().replace(ws, " ")
    }

    fun tokens(text: String): List<String> {
        val c = clean(text)
        if (c.isEmpty()) return emptyList()
        return c.split(" ").filter { it.isNotEmpty() }
    }

    /** Naam ka consonant-skeleton. "Rahul" aur "राहुल" dono -> "rl". */
    fun key(text: String): String {
        val cleaned = clean(text)
        val sb = StringBuilder()
        for (ch in cleaned) {
            val m = dev[ch]
            if (m != null) sb.append(m) else sb.append(ch)
        }
        var s = sb.toString()
        s = s.replace("ch", "c").replace("sh", "s").replace("kh", "k").replace("gh", "g")
            .replace("th", "t").replace("dh", "d").replace("bh", "b").replace("ph", "p")
            .replace("jh", "j").replace("ck", "k").replace("x", "ks")
            .replace('w', 'v').replace('q', 'k').replace('z', 'j')
        val out = StringBuilder()
        for (ch in s) {
            if ("aeiouyh".indexOf(ch) >= 0) continue
            if (!ch.isLetter()) continue
            if (out.isNotEmpty() && out[out.length - 1] == ch) continue
            out.append(ch)
        }
        return out.toString()
    }
}
