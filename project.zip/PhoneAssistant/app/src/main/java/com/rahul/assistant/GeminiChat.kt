package com.rahul.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Dost jaisi baat-cheet ke liye Google Gemini API.
 * API key sirf phone me save hoti hai (app ki screen se), code me kahin nahi.
 * ask() network use karta hai, isliye hamesha background thread se bulao.
 */
object GeminiChat {

    const val ERR_KEY = "key"
    const val ERR_MODEL = "model"
    const val ERR_LIMIT = "limit"
    const val ERR_NET = "net"
    const val ERR_OTHER = "other"

    data class Reply(val text: String?, val error: String?)

    private const val MAX_HISTORY = 10
    private val history = ArrayList<Pair<String, String>>() // (role, text)

    fun clear() {
        synchronized(history) { history.clear() }
    }

    private fun systemPrompt(hindi: Boolean, address: String): String {
        val addrRule = if (address.isBlank()) "" else {
            "यूज़र तुम्हारा मालिक है: उसे हमेशा '" + address + "' कहकर बुलाओ और " +
                "'जी " + address + "', 'ठीक है " + address + "' जैसे जवाब दो, पर अपनापन दोस्त जैसा रखो। " +
                "आदर के नाम पर हाँ में हाँ मत मिलाओ; ज़रूरत हो तो नरमी से सच या असहमति बताओ, " +
                "और ख़तरे या सेहत की बात पर टोकना मत छोड़ो। "
        }
        val script = if (hindi) {
            "जवाब हिंदी (देवनागरी) में दो, English शब्द बीच में चल सकते हैं।"
        } else {
            "Reply in simple Hinglish or English using Roman letters."
        }
        return "तुम 'दोस्त' हो: यूज़र का करीबी दोस्त जैसा फ़ोन असिस्टेंट। " +
            "यार की तरह गर्मजोशी, अपनापन और हल्के मज़ाक के साथ बात करो। " + script + " " + addrRule +
            "तुम्हारा जवाब बोलकर सुनाया जाएगा, इसलिए सिर्फ़ 1 से 3 छोटे वाक्य बोलो। " +
            "कोई लिस्ट, markdown, तारे, हैशटैग या emoji नहीं। " +
            "अगर यूज़र दुखी, थका हुआ या परेशान लगे तो पहले ध्यान से सुनो और हमदर्दी दिखाओ, फिर हल्के से मदद करो। " +
            "सिर्फ़ हाँ में हाँ मत मिलाओ; ज़रूरत हो तो सच्ची, नरम सलाह दो। " +
            "यूज़र बाइक चला रहा हो सकता है, इसलिए बात छोटी रखो और ऐसा कुछ मत कहो जिसमें स्क्रीन देखनी पड़े। " +
            "सेहत, कानून या पैसे जैसे गंभीर मामलों में सही जानकारी दो और ज़रूरत हो तो डॉक्टर या जानकार से मिलने को कहो। " +
            "कोई पूछे कि तुम इंसान हो या AI, तो सच बताओ कि तुम AI हो। " +
            "तुम कॉल, मैप्स और म्यूज़िक भी चला सकते हो, पर यहाँ सिर्फ़ बातचीत का जवाब दो।"
    }

    private fun sanitize(s: String): String {
        return s.replace(Regex("[*#_`~]"), "")
            .replace(Regex("[\\uD800-\\uDFFF]"), "") // emoji hatao, TTS unhe padhta hai
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun ask(apiKey: String, modelName: String, userText: String, hindi: Boolean, address: String): Reply {
        var conn: HttpURLConnection? = null
        try {
            val m = modelName.trim().removePrefix("models/").ifEmpty { AssistantService.DEFAULT_MODEL }
            val url = URL(
                "https://generativelanguage.googleapis.com/v1beta/models/" + m +
                    ":generateContent?key=" + URLEncoder.encode(apiKey.trim(), "UTF-8")
            )

            val contents = JSONArray()
            val snapshot = synchronized(history) { ArrayList(history) }
            for ((role, text) in snapshot) contents.put(turn(role, text))
            contents.put(turn("user", userText))

            val body = JSONObject()
                .put(
                    "system_instruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt(hindi, address))))
                )
                .put("contents", contents)
                .put(
                    "generationConfig",
                    JSONObject().put("temperature", 0.9).put("maxOutputTokens", 1024)
                )

            conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 25_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

            if (code !in 200..299) {
                val err = when {
                    code == 401 || code == 403 -> ERR_KEY
                    code == 400 && resp.contains("API key", ignoreCase = true) -> ERR_KEY
                    code == 404 -> ERR_MODEL
                    code == 429 -> ERR_LIMIT
                    else -> ERR_OTHER
                }
                return Reply(null, err)
            }

            val cands = JSONObject(resp).optJSONArray("candidates")
            if (cands == null || cands.length() == 0) return Reply(null, ERR_OTHER)
            val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.optBoolean("thought", false)) continue
                    sb.append(p.optString("text", ""))
                }
            }
            val reply = sanitize(sb.toString())
            if (reply.isEmpty()) return Reply(null, ERR_OTHER)

            synchronized(history) {
                history.add(Pair("user", userText))
                history.add(Pair("model", reply))
                while (history.size > MAX_HISTORY) history.removeAt(0)
            }
            return Reply(reply, null)
        } catch (e: IOException) {
            return Reply(null, ERR_NET)
        } catch (e: Exception) {
            return Reply(null, ERR_OTHER)
        } finally {
            conn?.disconnect()
        }
    }

    private fun turn(role: String, text: String): JSONObject =
        JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))
}
