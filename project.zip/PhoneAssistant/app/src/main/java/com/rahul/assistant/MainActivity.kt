package com.rahul.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var startBtn: Button
    private lateinit var langBtn: Button
    private lateinit var simBtn: Button
    private lateinit var keyInput: EditText
    private lateinit var modelInput: EditText
    private lateinit var addressInput: EditText

    private val required = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.ANSWER_PHONE_CALLS
    )

    private fun allPermissions(): Array<String> {
        val list = ArrayList<String>(required.toList())
        list.add(Manifest.permission.READ_CALL_LOG) // optional: sirf caller ka naam bolne ke liye
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        return list.toTypedArray()
    }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        fun label(s: String, size: Float, bold: Boolean = false): TextView {
            val t = TextView(this)
            t.text = s
            t.textSize = size
            if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
            t.setPadding(0, pad / 2, 0, pad / 2)
            return t
        }

        fun button(s: String, onClick: () -> Unit): Button {
            val b = Button(this)
            b.text = s
            b.isAllCaps = false
            b.setOnClickListener { onClick() }
            return b
        }

        root.addView(label("Dost - tumhara phone assistant", 22f, true))

        status = label("", 15f)
        root.addView(status)

        root.addView(button("1. Permissions do") {
            requestPermissions(allPermissions(), 100)
        })
        root.addView(button("2. 'Display over other apps' ON karo") { openOverlaySettings() })
        root.addView(button("3. Battery: Dost ko 'Unrestricted' karo") {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                Toast.makeText(this, "Settings me Battery se Dost ko Unrestricted karo", Toast.LENGTH_LONG).show()
            }
        })

        startBtn = button("Dost ON karo") { toggleService() }
        root.addView(startBtn)

        langBtn = button("") { toggleLang() }
        root.addView(langBtn)

        simBtn = button("") { toggleSim() }
        root.addView(simBtn)

        root.addView(button("Kaam karne ki ijazat wapas lo (dobara puchhega)") {
            getSharedPreferences(AssistantService.PREFS, Context.MODE_PRIVATE)
                .edit().remove(AssistantService.KEY_CONSENT).apply()
            Toast.makeText(this, "Ab Dost pehle kaam par dobara ijazat maangega", Toast.LENGTH_SHORT).show()
        })

        root.addView(label("Dost jaisi baat karne ke liye (Gemini)", 18f, true))
        root.addView(
            label(
                "aistudio.google.com/apikey pe jaake free API key banao aur yahan paste karo. " +
                    "Free plan me Google tumhari baatein apni service sudharne me use kar sakta hai, " +
                    "isliye bahut private baatein mat bolna.",
                14f
            )
        )
        val prefs = getSharedPreferences(AssistantService.PREFS, Context.MODE_PRIVATE)
        keyInput = EditText(this)
        keyInput.hint = "Gemini API key"
        keyInput.setSingleLine(true)
        keyInput.setText(prefs.getString(AssistantService.KEY_GEMINI, "") ?: "")
        root.addView(keyInput)
        modelInput = EditText(this)
        modelInput.hint = "Model ka naam"
        modelInput.setSingleLine(true)
        modelInput.setText(prefs.getString(AssistantService.KEY_MODEL, AssistantService.DEFAULT_MODEL))
        root.addView(modelInput)
        root.addView(label("Dost tumhe kya bulaye? (khali chhodo to kuch nahi bolega)", 14f))
        addressInput = EditText(this)
        addressInput.hint = "Jaise: मालिक"
        addressInput.setSingleLine(true)
        addressInput.setText(
            if (prefs.contains(AssistantService.KEY_ADDRESS)) {
                prefs.getString(AssistantService.KEY_ADDRESS, "") ?: ""
            } else {
                "मालिक"
            }
        )
        root.addView(addressInput)
        root.addView(button("Save karo") { saveChatSettings() })

        root.addView(
            label(
                "Kaise bolna hai:\n" +
                    "• Jarvis, Rahul ko call karo\n" +
                    "• Jarvis, 98765 43210 ko call karo\n" +
                    "• Jarvis, Barpeta bazaar ka rasta\n" +
                    "• Jarvis, gaana chalao\n" +
                    "• Jarvis, Arijit Singh ke gaane chalao\n" +
                    "• Jarvis, next / pause / volume badhao\n" +
                    "• Jarvis, yaar aaj bahut thak gaya (dost jaisi baat, upar Gemini key save karni hogi)\n" +
                    "• Baat ke beech Jarvis bolna zaroori nahi. Khatam karne ko bolo 'bye' ya 'bas'\n" +
                    "• Pehli baar koi kaam bologe to wo ek baar ijazat maangega, 'haan' bolna. Uske baad sab khud karega\n" +
                    "• Call aaye to bas bolo: 'uthao' ya 'kaato' (Jarvis bolna zaroori nahi)\n" +
                    "• 'Jarvis' ke badle 'Dost' ya 'Assistant' bhi chalega",
                15f
            )
        )

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun mark(ok: Boolean) = if (ok) "✅" else "❌"

    private fun refresh() {
        val running = AssistantService.isRunning
        status.text =
            "${mark(granted(Manifest.permission.RECORD_AUDIO))} Mic\n" +
                "${mark(granted(Manifest.permission.READ_PHONE_STATE))} Phone state\n" +
                "${mark(granted(Manifest.permission.READ_CONTACTS))} Contacts\n" +
                "${mark(granted(Manifest.permission.CALL_PHONE))} Call karna\n" +
                "${mark(granted(Manifest.permission.ANSWER_PHONE_CALLS))} Call uthana/kaatna\n" +
                "${mark(granted(Manifest.permission.READ_CALL_LOG))} Caller ka naam (optional)\n" +
                "${mark(Settings.canDrawOverlays(this))} Display over other apps\n" +
                "${mark(hasKey())} Gemini key (dost jaisi baat ke liye)\n" +
                "${mark(running)} Dost ${if (running) "chal raha hai" else "band hai"}"
        startBtn.text = if (running) "Dost OFF karo" else "Dost ON karo"
        langBtn.text = if (currentLang() == "hi-IN") "Bhasha: Hindi (badalne ke liye dabao)" else "Bhasha: English-India (badalne ke liye dabao)"
        simBtn.text = when (simChoice()) {
            1 -> "Call kis SIM se: SIM 1 (badalne ke liye dabao)"
            2 -> "Call kis SIM se: SIM 2 (badalne ke liye dabao)"
            else -> "Call kis SIM se: Auto (badalne ke liye dabao)"
        }
    }

    private fun simChoice(): Int =
        getSharedPreferences(AssistantService.PREFS, Context.MODE_PRIVATE).getInt(AssistantService.KEY_SIM, 0)

    private fun toggleSim() {
        val next = (simChoice() + 1) % 3
        getSharedPreferences(AssistantService.PREFS, Context.MODE_PRIVATE)
            .edit().putInt(AssistantService.KEY_SIM, next).apply()
        refresh()
    }

    private fun currentLang(): String =
        getSharedPreferences(AssistantService.PREFS, Context.MODE_PRIVATE)
            .getString(AssistantService.KEY_LANG, "hi-IN") ?: "hi-IN"

    private fun toggleLang() {
        val next = if (currentLang() == "hi-IN") "en-IN" else "hi-IN"
        getSharedPreferences(AssistantService.PREFS, Context.MODE_PRIVATE)
            .edit().putString(AssistantService.KEY_LANG, next).apply()
        refresh()
    }

    private fun hasKey(): Boolean =
        (getSharedPreferences(AssistantService.PREFS, Context.MODE_PRIVATE)
            .getString(AssistantService.KEY_GEMINI, "") ?: "").isNotBlank()

    private fun saveChatSettings() {
        val key = keyInput.text.toString().trim()
        val model = keyInputModel()
        getSharedPreferences(AssistantService.PREFS, Context.MODE_PRIVATE).edit()
            .putString(AssistantService.KEY_GEMINI, key)
            .putString(AssistantService.KEY_MODEL, model)
            .putString(AssistantService.KEY_ADDRESS, addressInput.text.toString().trim())
            .apply()
        Toast.makeText(this, "Save ho gaya", Toast.LENGTH_SHORT).show()
        refresh()
    }

    private fun keyInputModel(): String =
        modelInput.text.toString().trim().ifEmpty { AssistantService.DEFAULT_MODEL }

    private fun openOverlaySettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Settings me 'Display over other apps' dhundo", Toast.LENGTH_LONG).show()
        }
    }

    private fun toggleService() {
        if (AssistantService.isRunning) {
            stopService(Intent(this, AssistantService::class.java))
            status.postDelayed({ refresh() }, 500)
            return
        }
        val missing = required.filter { !granted(it) }
        if (missing.isNotEmpty()) {
            Toast.makeText(this, "Pehle saari permissions do", Toast.LENGTH_LONG).show()
            requestPermissions(allPermissions(), 100)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "'Display over other apps' ON karo, tabhi Maps/Call khulenge", Toast.LENGTH_LONG).show()
            openOverlaySettings()
            return
        }
        startForegroundService(Intent(this, AssistantService::class.java))
        status.postDelayed({ refresh() }, 700)
    }
}
