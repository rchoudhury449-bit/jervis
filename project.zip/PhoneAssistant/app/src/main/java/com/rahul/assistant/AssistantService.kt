package com.rahul.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.SearchManager
import android.app.Service
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import java.util.Locale

/**
 * Dost ka dimaag. Foreground service jo hamesha mic sunta rehta hai:
 *  - Call aaye to naam bolta hai aur "uthao" / "kaato" sunta hai
 *  - "Jarvis, ..." se shuru hone wale commands (call, maps, music, volume)
 */
class AssistantService : Service() {

    companion object {
        const val ACTION_STOP = "com.rahul.assistant.STOP"
        const val CHANNEL_ID = "dost_assistant"
        const val NOTIF_ID = 11
        const val PREFS = "dost_prefs"
        const val KEY_LANG = "lang"
        const val KEY_GEMINI = "gemini_key"
        const val KEY_MODEL = "gemini_model"
        const val KEY_ADDRESS = "address"
        const val KEY_SIM = "sim_choice" // 0 = auto, 1 = SIM 1, 2 = SIM 2
        const val KEY_CONSENT = "auto_consent"
        const val DEFAULT_MODEL = "gemini-3.5-flash-lite"

        @Volatile
        var isRunning = false
    }

    private enum class Mode { IDLE, AWAIT_COMMAND, AWAIT_CALL_TARGET, CHAT, AWAIT_CONSENT }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var audio: AudioManager
    private lateinit var telecom: TelecomManager

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsHindi = true
    private var recognizer: SpeechRecognizer? = null
    private var started = false
    private var destroyed = false

    private var speaking = 0
    private var utteranceCounter = 0
    private val activeUtterances = HashSet<String>()
    private val pendingDone = HashMap<String, () -> Unit>()
    private var focusRequest: AudioFocusRequest? = null

    private var mode = Mode.IDLE
    private var modeDeadline = 0L

    private var ringing = false
    private var ringAnnounced = false
    private var ringNumber: String? = null
    private var offhook = false
    private var thinking = false // Gemini ke jawab ka intezaar
    private var pendingCmd: Command? = null // ijazat milne tak ruka hua kaam

    private var overlayView: View? = null
    private var receiverRegistered = false

    // ------------------------------------------------------------------ lifecycle

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        telecom = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
        createChannel()
        isRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            showForeground()
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!started) {
            started = true
            begin()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        destroyed = true
        isRunning = false
        main.removeCallbacksAndMessages(null)
        stopListening()
        if (receiverRegistered) {
            try {
                unregisterReceiver(phoneReceiver)
            } catch (e: Exception) {
            }
        }
        tts?.stop()
        tts?.shutdown()
        tts = null
        GeminiChat.clear()
        abandonDuck()
        removeOverlayAnchor()
        super.onDestroy()
    }

    private fun begin() {
        addOverlayAnchor()
        registerPhoneReceiver()
        tts = TextToSpeech(applicationContext) { status -> main.post { onTtsInit(status) } }
    }

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Dost Assistant", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun showForeground() {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, AssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Band karo",
            stop
        ).build()
        val n = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Dost sun raha hai")
            .setContentText("Bolo: Jarvis, Rahul ko call karo")
            .setContentIntent(open)
            .addAction(stopAction)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    /**
     * Ek 1x1 invisible overlay window. Android background se Maps/Dialer kholne nahi deta,
     * lekin jis app ki koi window dikh rahi ho use rok nahi lagti.
     */
    private fun addOverlayAnchor() {
        if (!Settings.canDrawOverlays(this)) return
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val v = View(this)
            val lp = WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(v, lp)
            overlayView = v
        } catch (e: Exception) {
        }
    }

    private fun removeOverlayAnchor() {
        val v = overlayView ?: return
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (e: Exception) {
        }
        overlayView = null
    }

    // ------------------------------------------------------------------ speech out (TTS)

    private fun tr(hi: String, en: String): String = if (ttsHindi) hi else en

    /** User ko kya bulana hai (app me badal sakte ho). Save kiya hua khali ho to kuch nahi bolega. */
    private fun addr(): String {
        val p = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return if (p.contains(KEY_ADDRESS)) {
            (p.getString(KEY_ADDRESS, "") ?: "").trim()
        } else if (ttsHindi) {
            "मालिक"
        } else {
            "maalik"
        }
    }

    /** "जी मालिक, " jaisa shuruaat ka hissa. */
    private fun ji(): String {
        val a = addr()
        return if (a.isEmpty()) "" else tr("जी $a, ", "Yes $a, ")
    }

    /** " मालिक" jaisa ant ka hissa. */
    private fun sfx(): String {
        val a = addr()
        return if (a.isEmpty()) "" else " $a"
    }

    private fun onTtsInit(status: Int) {
        if (destroyed) return
        val t = tts
        if (status == TextToSpeech.SUCCESS && t != null) {
            val r = t.setLanguage(Locale("hi", "IN"))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                ttsHindi = false
                t.setLanguage(Locale("en", "IN"))
            }
            t.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}

                override fun onDone(utteranceId: String?) {
                    utteranceId?.let { id -> main.post { finishUtterance(id) } }
                }

                @Suppress("OVERRIDE_DEPRECATION")
                override fun onError(utteranceId: String?) {
                    utteranceId?.let { id -> main.post { finishUtterance(id) } }
                }
            })
            ttsReady = true
            speak(ji() + tr("मैं तैयार हूँ। बोलिए।", "I am ready. Go ahead."))
        } else {
            ttsReady = false
            scheduleListen(0)
        }
    }

    private fun speak(text: String, onDone: (() -> Unit)? = null) {
        val id = "u" + (utteranceCounter++)
        if (onDone != null) pendingDone[id] = onDone
        val t = tts
        if (!ttsReady || t == null) {
            main.post {
                pendingDone.remove(id)?.invoke()
                scheduleListen(300)
            }
            return
        }
        if (speaking == 0) {
            stopListening()
            requestDuck()
        }
        speaking++
        activeUtterances.add(id)
        val result = t.speak(text, TextToSpeech.QUEUE_ADD, null, id)
        if (result != TextToSpeech.SUCCESS) main.post { finishUtterance(id) }
    }

    private fun finishUtterance(id: String) {
        if (!activeUtterances.remove(id)) return
        if (speaking > 0) speaking--
        pendingDone.remove(id)?.invoke()
        if (speaking == 0) {
            abandonDuck()
            if (mode != Mode.IDLE) {
                modeDeadline = SystemClock.elapsedRealtime() + (if (mode == Mode.CHAT) 25_000 else 10_000)
            }
            scheduleListen(250)
        }
    }

    private fun requestDuck() {
        if (focusRequest != null) return
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(attrs)
            .build()
        focusRequest = req
        audio.requestAudioFocus(req)
    }

    private fun abandonDuck() {
        focusRequest?.let { audio.abandonAudioFocusRequest(it) }
        focusRequest = null
    }

    // ------------------------------------------------------------------ speech in (mic)

    private val listenRunnable = Runnable { startListening() }

    private fun scheduleListen(delayMs: Long) {
        main.removeCallbacks(listenRunnable)
        main.postDelayed(listenRunnable, delayMs)
    }

    private fun canListen(): Boolean = !destroyed && speaking == 0 && !offhook && !thinking

    private fun startListening() {
        if (!canListen()) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak(
                tr(
                    "स्पीच रिकग्निशन उपलब्ध नहीं है। गूगल ऐप अपडेट कीजिए।",
                    "Speech recognition is not available. Please update the Google app."
                )
            ) { stopSelf() }
            return
        }
        stopListening()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(listener)
        recognizer = r

        val lang = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LANG, "hi-IN") ?: "hi-IN"
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        try {
            r.startListening(i)
        } catch (e: Exception) {
            scheduleListen(2000)
        }
    }

    private fun stopListening() {
        main.removeCallbacks(listenRunnable)
        val r = recognizer
        recognizer = null
        if (r != null) {
            try {
                r.cancel()
            } catch (e: Exception) {
            }
            try {
                r.destroy()
            } catch (e: Exception) {
            }
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (destroyed) return
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    speak(tr("माइक की अनुमति चाहिए", "Microphone permission needed")) { stopSelf() }
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    scheduleListen(150)
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                    scheduleListen(1500)
                else -> scheduleListen(1200)
            }
        }

        override fun onResults(results: Bundle?) {
            if (destroyed) return
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
            handleResults(list)
            if (speaking == 0) scheduleListen(200)
        }
    }

    // ------------------------------------------------------------------ brain

    private fun setMode(m: Mode) {
        mode = m
        modeDeadline = if (m == Mode.IDLE) 0L
        else SystemClock.elapsedRealtime() + (if (m == Mode.CHAT) 25_000 else 12_000)
    }

    private fun currentMode(): Mode {
        if (mode != Mode.IDLE && SystemClock.elapsedRealtime() > modeDeadline) mode = Mode.IDLE
        return mode
    }

    private fun handleResults(hyps: List<String>) {
        if (hyps.isEmpty()) return
        if (ringing) {
            handleRinging(hyps)
            return
        }
        if (thinking) return
        when (currentMode()) {
            Mode.AWAIT_CALL_TARGET -> handleCallTarget(hyps)
            Mode.AWAIT_COMMAND -> handleAwaitedCommand(hyps)
            Mode.CHAT -> handleChat(hyps)
            Mode.AWAIT_CONSENT -> handleConsent(hyps)
            Mode.IDLE -> handleIdle(hyps)
        }
    }

    private fun handleRinging(hyps: List<String>) {
        for (h in hyps) {
            when (CommandParser.parseRinging(h)) {
                CommandParser.RingAction.REJECT -> {
                    rejectCall()
                    return
                }
                CommandParser.RingAction.ANSWER -> {
                    answerCall()
                    return
                }
                null -> {}
            }
        }
    }

    private fun handleIdle(hyps: List<String>) {
        var heardWake = false
        var firstRest: String? = null
        for (h in hyps) {
            val rest = CommandParser.stripWakeWord(h) ?: continue
            heardWake = true
            if (rest.isBlank()) continue
            if (firstRest == null) firstRest = rest
            val cmd = CommandParser.parse(rest)
            if (cmd !is Command.Unknown) {
                execute(cmd)
                return
            }
        }
        if (!heardWake) return
        if (firstRest != null) {
            // Koi command nahi mila, to ise dost ki baat maano.
            startChat(firstRest)
        } else {
            setMode(Mode.AWAIT_COMMAND)
            speak(ji() + tr("बोलिए", "Go ahead"))
        }
    }

    private fun handleAwaitedCommand(hyps: List<String>) {
        for (h in hyps) {
            val cmd = CommandParser.parse(CommandParser.stripWakeWord(h) ?: h)
            if (cmd !is Command.Unknown) {
                execute(cmd)
                return
            }
        }
        startChat(CommandParser.stripWakeWord(hyps[0]) ?: hyps[0])
    }

    // ------------------------------------------------------------------ dost jaisi baat (Gemini)

    private fun handleChat(hyps: List<String>) {
        val first = hyps[0]
        if (CommandParser.isGoodbye(first) || CommandParser.parse(first) is Command.Cancel) {
            setMode(Mode.IDLE)
            speak(tr("ठीक है", "Okay") + sfx() + tr(", फिर बात करते हैं!", ", talk to you later!"))
            return
        }
        // Wake word ke saath bola command (jaise "Jarvis, gaana chalao") chat ke beech bhi chalta hai.
        for (h in hyps) {
            val rest = CommandParser.stripWakeWord(h) ?: continue
            if (rest.isBlank()) continue
            val cmd = CommandParser.parse(rest)
            if (cmd !is Command.Unknown) {
                execute(cmd)
                return
            }
        }
        val stripped = CommandParser.stripWakeWord(first)
        startChat(if (!stripped.isNullOrBlank()) stripped else first)
    }

    private fun startChat(userText: String) {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = (prefs.getString(KEY_GEMINI, "") ?: "").trim()
        if (key.isEmpty()) {
            setMode(Mode.IDLE)
            speak(
                tr(
                    "बात करने के लिए पहले ऐप में Gemini API key डालिए",
                    "To chat, first add the Gemini API key in the app"
                )
            )
            return
        }
        val model = prefs.getString(KEY_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL
        val hindi = ttsHindi
        val address = addr()
        stopListening()
        thinking = true
        Thread {
            val reply = GeminiChat.ask(key, model, userText, hindi, address)
            main.post { onChatReply(reply) }
        }.start()
    }

    private fun onChatReply(r: GeminiChat.Reply) {
        thinking = false
        if (destroyed) return
        // Beech me call aa gaya ho to jawab chhod do; onIdle() sunna dobara shuru karega.
        if (ringing || offhook) return
        val text = r.text
        if (text != null) {
            setMode(Mode.CHAT)
            speak(text)
            return
        }
        setMode(Mode.IDLE)
        val msg = when (r.error) {
            GeminiChat.ERR_KEY -> tr("Gemini की key सही नहीं लग रही", "The Gemini key looks wrong")
            GeminiChat.ERR_MODEL -> tr(
                "Gemini मॉडल का नाम सही नहीं है, ऐप में बदलिए",
                "The Gemini model name is wrong, change it in the app"
            )
            GeminiChat.ERR_LIMIT -> tr(
                "फ्री लिमिट पूरी हो गई, थोड़ी देर बाद बात करते हैं",
                "Free limit reached, let's talk a bit later"
            )
            GeminiChat.ERR_NET -> tr("इंटरनेट नहीं चल रहा", "No internet connection")
            else -> tr("कुछ गड़बड़ हो गई, दोबारा बोलिए", "Something went wrong, please say that again")
        }
        speak(msg)
    }

    private fun handleCallTarget(hyps: List<String>) {
        for (h in hyps) {
            if (CommandParser.parse(CommandParser.stripWakeWord(h) ?: h) is Command.Cancel) {
                execute(Command.Cancel)
                return
            }
        }
        val first = CommandParser.stripWakeWord(hyps[0]) ?: hyps[0]
        startCall(CommandParser.callTarget(first))
    }

    private fun hasConsent(): Boolean =
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_CONSENT, false)

    /** Pehli baar koi kaam bola jaye to ek baar ijazat maangta hai, uske baad seedha karta hai. */
    private fun execute(cmd: Command) {
        setMode(Mode.IDLE)
        if (cmd is Command.Cancel || cmd is Command.Unknown || hasConsent()) {
            runCommand(cmd)
            return
        }
        pendingCmd = cmd
        setMode(Mode.AWAIT_CONSENT)
        speak(
            tr(
                "कॉल, मैप्स और म्यूज़िक जैसे काम खुद करने के लिए आपकी इजाज़त चाहिए${sfx()}। एक बार हाँ बोल दीजिए, फिर मैं हर बार नहीं पूछूँगा।",
                "I need your permission to place calls, open maps and play music on my own${sfx()}. Say yes once, and I will not ask again."
            )
        )
    }

    private fun handleConsent(hyps: List<String>) {
        var decision: Boolean? = null
        for (h in hyps) {
            decision = CommandParser.parseConsent(h)
            if (decision != null) break
        }
        val cmd = pendingCmd
        pendingCmd = null
        setMode(Mode.IDLE)
        when (decision) {
            true -> {
                getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_CONSENT, true).apply()
                speak(
                    tr(
                        "धन्यवाद${sfx()}। अब से आप जो कहेंगे, मैं खुद कर दूँगा।",
                        "Thank you${sfx()}. From now on I will do whatever you ask on my own."
                    )
                ) { if (cmd != null) runCommand(cmd) }
            }
            false -> speak(tr("ठीक है${sfx()}, मैं कुछ नहीं करूँगा।", "Understood${sfx()}, I will not do anything."))
            null -> speak(tr("समझ नहीं आया${sfx()}, दोबारा कहिए।", "Sorry${sfx()}, please say that again."))
        }
    }

    private fun runCommand(cmd: Command) {
        setMode(Mode.IDLE)
        when (cmd) {
            is Command.Cancel -> speak(tr("ठीक है", "Okay") + sfx())
            is Command.Call -> startCall(cmd.target)
            is Command.Navigate -> startNavigation(cmd.destination)
            is Command.MusicPlay -> musicPlay()
            is Command.MusicSearch -> musicSearch(cmd.query)
            is Command.MusicPause -> mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE)
            is Command.MusicNext -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
            is Command.MusicPrev -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            is Command.VolumeUp -> changeVolume(true)
            is Command.VolumeDown -> changeVolume(false)
            is Command.Unknown -> {}
        }
    }

    // ------------------------------------------------------------------ incoming calls

    private val phoneReceiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
            val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
            val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
            when (state) {
                TelephonyManager.EXTRA_STATE_RINGING -> onRinging(number)
                TelephonyManager.EXTRA_STATE_OFFHOOK -> onOffhook()
                TelephonyManager.EXTRA_STATE_IDLE -> onIdle()
            }
        }
    }

    private fun registerPhoneReceiver() {
        val f = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(phoneReceiver, f, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(phoneReceiver, f)
        }
        receiverRegistered = true
    }

    private fun onRinging(number: String?) {
        if (!number.isNullOrBlank()) ringNumber = number
        if (ringing) return
        ringing = true
        ringAnnounced = false
        setMode(Mode.IDLE)
        stopListening()
        // Number aksar doosre broadcast me aata hai, isliye thoda ruk ke bolte hain.
        main.postDelayed({ announceCall() }, 900)
    }

    private fun announceCall() {
        if (destroyed || !ringing || ringAnnounced) return
        ringAnnounced = true
        val name = ringNumber?.let { lookupName(it) }
        val text = if (name != null) {
            tr("$name का कॉल आ रहा है${sfx()}। उठाना है या काटना है?", "Call from $name${sfx()}. Answer or reject?")
        } else {
            tr("कॉल आ रहा है${sfx()}। उठाना है या काटना है?", "Incoming call${sfx()}. Answer or reject?")
        }
        speak(text)
    }

    private fun lookupName(number: String): String? {
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
            )
            contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }

    private fun onOffhook() {
        ringing = false
        offhook = true
        setMode(Mode.IDLE)
        stopListening()
    }

    private fun onIdle() {
        ringing = false
        offhook = false
        if (started && !destroyed) scheduleListen(1500)
    }

    private fun answerCall() {
        ringing = false
        try {
            telecom.acceptRingingCall()
        } catch (e: SecurityException) {
            speak(tr("कॉल उठाने की अनुमति नहीं है", "No permission to answer calls"))
        } catch (e: Exception) {
        }
    }

    private fun rejectCall() {
        ringing = false
        try {
            telecom.endCall()
        } catch (e: SecurityException) {
            speak(tr("कॉल काटने की अनुमति नहीं है", "No permission to end calls"))
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------------ outgoing calls

    private fun startCall(rawTarget: String) {
        val target = rawTarget.trim()
        if (target.isEmpty()) {
            setMode(Mode.AWAIT_CALL_TARGET)
            speak(tr("किसे कॉल करना है${sfx()}?", "Whom should I call${sfx()}?"))
            return
        }
        val digits = target.filter { it.isDigit() }.map { Character.digit(it, 10) }.joinToString("")
        if (digits.length >= 7) {
            speak(ji() + tr("इस नंबर पर कॉल लगा रहा हूँ", "Calling this number")) { placeCall(digits) }
            return
        }
        Thread {
            val hits = try {
                ContactMatcher.find(applicationContext, target)
            } catch (e: Exception) {
                emptyList()
            }
            main.post { onContactsFound(target, hits) }
        }.start()
    }

    private fun onContactsFound(target: String, hits: List<ContactHit>) {
        if (destroyed) return
        when {
            hits.isEmpty() -> {
                setMode(Mode.AWAIT_CALL_TARGET)
                speak(
                    tr(
                        "$target नाम का कॉन्टैक्ट नहीं मिला। दोबारा नाम बोलिए।",
                        "No contact found for $target. Say the name again."
                    )
                )
            }
            hits.size == 1 -> {
                val h = hits[0]
                speak(ji() + tr("${h.name} को कॉल लगा रहा हूँ", "Calling ${h.name}")) { placeCall(h.number) }
            }
            else -> {
                val names = hits.take(3).joinToString(", ") { it.name }
                setMode(Mode.AWAIT_CALL_TARGET)
                speak(
                    tr(
                        "कई कॉन्टैक्ट मिले: $names। पूरा नाम बोलिए।",
                        "Several matches: $names. Say the full name."
                    )
                )
            }
        }
    }

    /**
     * Dual SIM phone me ACTION_CALL "kaunsa SIM?" ka sawal khol deta hai aur wahi ruk jaata hai.
     * Isliye SIM khud chunke TelecomManager se seedha call lagate hain.
     */
    private fun pickSim(): PhoneAccountHandle? {
        return try {
            val accounts = telecom.callCapablePhoneAccounts
            val choice = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_SIM, 0)
            if (choice >= 1 && choice <= accounts.size) {
                accounts[choice - 1]
            } else {
                telecom.getDefaultOutgoingPhoneAccount("tel") ?: accounts.firstOrNull()
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun placeCall(number: String) {
        try {
            val extras = Bundle()
            pickSim()?.let { extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, it) }
            telecom.placeCall(Uri.fromParts("tel", number, null), extras)
        } catch (e: SecurityException) {
            speak(tr("कॉल करने की अनुमति नहीं है", "No permission to place calls"))
        } catch (e: Exception) {
            try {
                val i = Intent(Intent.ACTION_CALL, Uri.fromParts("tel", number, null))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (e2: Exception) {
                speak(tr("कॉल नहीं लग पाया", "Could not place the call"))
            }
        }
    }

    // ------------------------------------------------------------------ maps

    private fun startNavigation(dest: String) {
        if (dest.isBlank()) {
            speak(ji() + tr("मैप्स खोल रहा हूँ", "Opening Maps")) { openMapsHome() }
            return
        }
        speak(ji() + tr("$dest का रास्ता खोल रहा हूँ", "Starting navigation to $dest")) { launchNavigation(dest) }
    }

    private fun launchNavigation(dest: String) {
        val nav = Uri.parse("google.navigation:q=" + Uri.encode(dest) + "&mode=l")
        try {
            val i = Intent(Intent.ACTION_VIEW, nav)
            i.setPackage("com.google.android.apps.maps")
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            try {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(dest)))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (e2: Exception) {
                speak(tr("मैप्स ऐप नहीं मिला", "Maps app not found"))
            }
        } catch (e: Exception) {
            speak(tr("मैप्स नहीं खुल पाया", "Could not open Maps"))
        }
    }

    private fun openMapsHome() {
        try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0"))
            i.setPackage("com.google.android.apps.maps")
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            speak(tr("मैप्स ऐप नहीं मिला", "Maps app not found"))
        }
    }

    // ------------------------------------------------------------------ music + volume

    private fun mediaKey(code: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun musicPlay() {
        mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY)
        // Agar 1.5 second me kuch nahi bajna shuru hua to default music app khol do.
        main.postDelayed({
            if (!destroyed && !audio.isMusicActive) openMusicApp()
        }, 1500)
    }

    private fun openMusicApp() {
        try {
            val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            speak(tr("म्यूज़िक ऐप नहीं मिला", "No music app found"))
        }
    }

    private fun musicSearch(query: String) {
        speak(ji() + tr("$query चला रहा हूँ", "Playing $query")) {
            try {
                val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                i.putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                i.putExtra(SearchManager.QUERY, query)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (e: Exception) {
                speak(tr("म्यूज़िक ऐप नहीं मिला", "No music app found"))
            }
        }
    }

    private fun changeVolume(up: Boolean) {
        val dir = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        repeat(2) {
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        }
    }
}
