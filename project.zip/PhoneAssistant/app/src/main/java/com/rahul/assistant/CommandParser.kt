package com.rahul.assistant

sealed class Command {
    data class Call(val target: String) : Command()
    data class Navigate(val destination: String) : Command()
    data class MusicSearch(val query: String) : Command()
    object MusicPlay : Command()
    object MusicPause : Command()
    object MusicNext : Command()
    object MusicPrev : Command()
    object VolumeUp : Command()
    object VolumeDown : Command()
    object Cancel : Command()
    object Unknown : Command()
}

/**
 * Bole hue text se command samajhta hai. Hindi (Devanagari), Hinglish aur English teeno ke
 * shabd yahan hain. Koi shabd galat pakda jaye to bas yahan ki list badalni hai.
 */
object CommandParser {

    enum class RingAction { ANSWER, REJECT }

    private fun kw(vararg w: String): Set<String> = w.map { Phonetic.nfc(it) }.toSet()

    // ---- Wake word: command se pehle yeh bolna hai ----
    val wakeWords = kw(
        "jarvis", "dost", "assistant",
        "जार्विस", "जारविस", "जर्विस", "जार्विज", "दोस्त",
        "असिस्टेंट", "असिस्टेन्ट", "अस्सिस्टेंट"
    )
    private val wakePrefix = kw("hey", "hi", "hello", "ok", "okay", "oye", "हे", "हेलो", "हैलो", "ओके", "ओए", "अरे")

    // ---- Call aane par ----
    private val answerWords = kw(
        "uthao", "उठाओ", "utha", "उठा", "uthana", "उठाना", "uthalo", "उठालो",
        "receive", "रिसीव", "रिसिव", "answer", "accept", "एक्सेप्ट", "pick", "पिक",
        "haan", "हाँ", "हां", "yes"
    )
    private val rejectWords = kw(
        "kato", "kaato", "काटो", "kaat", "काट", "katna", "काटना", "kat", "कट",
        "reject", "रिजेक्ट", "cut", "decline", "disconnect",
        "nahi", "नहीं", "no", "mat", "मत"
    )

    // ---- Normal commands ----
    private val cancelWords = kw("cancel", "कैंसल", "रहने", "rehne", "rahne", "छोड़ो", "छोड़", "chhodo", "chodo", "chhod")

    private val volumeWords = kw("volume", "वॉल्यूम", "वोल्यूम", "वॉल्युम", "awaaz", "awaz", "आवाज", "आवाज़", "sound", "साउंड")
    private val volUp = kw("badhao", "बढ़ाओ", "बढ़ा", "badhana", "zyada", "jyada", "ज्यादा", "ज़्यादा", "up", "increase", "tez", "तेज", "तेज़", "loud", "high", "ऊपर", "full")
    private val volDown = kw("kam", "कम", "ghatao", "घटाओ", "घटा", "ghata", "down", "decrease", "dheere", "धीरे", "low", "neeche", "नीचे", "halka", "हल्का")

    private val pauseWords = kw("pause", "पॉज़", "पॉज", "पोज़", "ruko", "रुको", "roko", "रोको", "rok", "रोक", "thehro", "ठहरो")
    private val stopWords = kw("stop", "स्टॉप", "band", "बंद", "बन्द")
    private val nextWords = kw("next", "नेक्स्ट", "agla", "अगला", "agle", "अगले", "skip", "स्किप", "dusra", "दूसरा", "badlo", "बदलो")
    private val prevWords = kw("previous", "प्रीवियस", "prev", "pichla", "पिछला", "pichle", "पिछले", "peeche", "पीछे", "back")

    private val musicNouns = kw("gaana", "gana", "gaane", "gane", "गाना", "गाने", "song", "songs", "सॉन्ग", "सांग", "music", "म्यूजिक", "म्यूज़िक", "संगीत")
    private val playWords = kw("play", "प्ले", "chalao", "चलाओ", "chalana", "चलाना", "bajao", "बजाओ", "bajana", "बजाना", "sunao", "सुनाओ", "sunana", "सुनाना", "resume", "shuru", "शुरू")
    private val musicFiller = kw(
        "ke", "के", "ka", "का", "ki", "की", "ko", "को", "ek", "एक", "mera", "मेरा", "mere", "मेरे",
        "koi", "कोई", "please", "plz", "do", "दो", "karo", "करो", "kar", "कर", "achha", "accha", "अच्छा",
        "wala", "वाला", "wale", "वाले", "mujhe", "मुझे", "pe", "पर", "par", "me", "में", "hai", "है",
        "ab", "अब", "phir", "फिर", "dobara"
    )

    private val navWords = kw(
        "map", "maps", "मैप", "मैप्स", "मेप", "navigate", "navigation", "नेविगेट", "नेविगेशन",
        "rasta", "raasta", "रास्ता", "रस्ता", "रास्ते", "route", "रूट", "direction", "directions", "डायरेक्शन",
        "chalo", "चलो", "jana", "जाना", "jaana", "jao", "जाओ", "pahuncha", "पहुंचा", "पहुँचा", "pahunchao", "पहुंचाओ", "पहुँचाओ"
    )
    private val navFiller = kw(
        "kholo", "खोलो", "open", "ओपन", "ka", "का", "ke", "के", "ki", "की", "ko", "को",
        "dikhao", "दिखाओ", "batao", "बताओ", "bata", "बता", "do", "दो", "hai", "है",
        "mujhe", "मुझे", "mere", "मेरे", "please", "plz", "to", "tak", "तक", "pe", "पर", "par",
        "me", "में", "le", "ले", "lena", "लेना", "chaliye", "चलिए", "start", "शुरू", "shuru",
        "karo", "करो", "kar", "कर", "google", "गूगल", "gaadi", "गाड़ी", "ab", "अब", "wapas"
    )

    private val callWords = kw(
        "call", "calls", "phone", "dial", "कॉल", "काल", "फोन", "फ़ोन",
        "lagao", "लगाओ", "milao", "मिलाओ", "ring"
    )
    // "phone" aur "baat" dost-baat me bhi aate hain ("mujhse baat karo"), isliye akele call nahi maante.
    private val phoneWords = kw("phone", "फोन", "फ़ोन")
    private val callVerbs = kw("karo", "करो", "kar", "कर", "laga", "लगा", "karna", "करना")
    private val baatWords = kw("baat", "बात")
    private val connectVerbs = kw("karao", "कराओ", "karwao", "करवाओ")
    private val extraCallFiller = kw(
        "laga", "लगा", "baat", "बात", "karao", "कराओ", "karwao", "करवाओ", "phone", "फोन", "फ़ोन"
    )

    // Maps tabhi kholna hai jab "map/rasta/navigate" jaisa saaf shabd ho, ya "le chalo".
    private val navStrong = kw(
        "map", "maps", "मैप", "मैप्स", "मेप", "navigate", "navigation", "नेविगेट", "नेविगेशन",
        "rasta", "raasta", "रास्ता", "रस्ता", "रास्ते", "route", "रूट", "direction", "directions", "डायरेक्शन"
    )
    private val leWords = kw("le", "ले")
    private val chaloWords = kw("chalo", "चलो")

    // Dost-baat khatam karne ke shabd
    private val goodbyeWords = kw("bye", "byee", "बाय", "bas", "बस", "alvida", "अलविदा", "chup", "चुप", "tata", "टाटा")

    fun isGoodbye(text: String): Boolean = Phonetic.tokens(text).any { it in goodbyeWords }

    private val callFiller = kw(
        "karo", "करो", "kar", "कर", "do", "दो", "ko", "को", "se", "से", "ka", "का", "ek", "एक",
        "mujhe", "मुझे", "mera", "मेरा", "mere", "मेरे", "please", "plz", "na", "ना",
        "karna", "करना", "karni", "करनी", "karwao", "करवाओ", "karao", "कराओ", "kijiye", "कीजिए",
        "hai", "है", "to", "तो", "pe", "पर", "par", "me", "में", "aur", "zara", "जरा", "ज़रा", "jara",
        "jaldi", "जल्दी", "lagana", "लगाना", "milana", "मिलाना", "number", "नंबर", "नम्बर", "mobile", "मोबाइल"
    )

    /** Agar text wake word se shuru hota hai to uske baad ka hissa lautata hai, warna null. */
    fun stripWakeWord(text: String): String? {
        val tokens = Phonetic.tokens(text)
        var i = 0
        if (i < tokens.size && tokens[i] in wakePrefix) i++
        if (i < tokens.size && tokens[i] in wakeWords) {
            return tokens.drop(i + 1).joinToString(" ")
        }
        return null
    }

    fun parseRinging(text: String): RingAction? {
        val tokens = Phonetic.tokens(text)
        if (tokens.any { it in rejectWords }) return RingAction.REJECT
        if (tokens.any { it in answerWords }) return RingAction.ANSWER
        return null
    }

    fun callTarget(text: String): String = callTarget(Phonetic.tokens(text))

    private fun callTarget(tokens: List<String>): String =
        tokens.filter {
            it !in callWords && it !in callFiller && it !in extraCallFiller &&
                it !in wakeWords && it !in wakePrefix
        }.joinToString(" ")

    fun parse(text: String): Command {
        val tokens = Phonetic.tokens(text)
        if (tokens.isEmpty()) return Command.Unknown
        fun has(words: Set<String>) = tokens.any { it in words }

        if (has(cancelWords)) return Command.Cancel

        if (has(volumeWords)) {
            if (has(volUp)) return Command.VolumeUp
            if (has(volDown)) return Command.VolumeDown
        }

        if (has(pauseWords) || (has(stopWords) && (has(musicNouns) || tokens.size == 1))) {
            return Command.MusicPause
        }
        if (has(nextWords)) return Command.MusicNext
        if (has(prevWords)) return Command.MusicPrev

        if (has(navWords)) {
            val dest = tokens.filter { it !in navWords && it !in navFiller }.joinToString(" ")
            val leChalo = has(leWords) && has(chaloWords)
            if (has(navStrong) || leChalo) return Command.Navigate(dest)
        }

        val strongCall = tokens.any { it in callWords && it !in phoneWords }
        val phoneCall = has(phoneWords) && has(callVerbs)
        val connectCall = has(baatWords) && has(connectVerbs)
        if (strongCall || phoneCall || connectCall) return Command.Call(callTarget(tokens))

        if (has(playWords) || has(musicNouns)) {
            val q = tokens.filter { it !in playWords && it !in musicNouns && it !in musicFiller }
                .joinToString(" ")
            return if (q.isEmpty()) Command.MusicPlay else Command.MusicSearch(q)
        }

        return Command.Unknown
    }
}
