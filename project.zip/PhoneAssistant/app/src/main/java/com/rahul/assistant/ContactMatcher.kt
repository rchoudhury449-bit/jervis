package com.rahul.assistant

import android.content.Context
import android.provider.ContactsContract.CommonDataKinds.Phone

data class ContactHit(val name: String, val number: String)

object ContactMatcher {

    /**
     * Bole hue naam se milte contacts. Sirf sabse accha score wale lautata hai.
     * Ek se zyada naam lauta to matlab confusion hai ("Rahul Sharma" aur "Rahul Das").
     */
    fun find(context: Context, spoken: String): List<ContactHit> {
        val q = Phonetic.clean(spoken)
        if (q.isEmpty()) return emptyList()
        val qKey = Phonetic.key(spoken)
        val qTokKeys = Phonetic.tokens(spoken).map { Phonetic.key(it) }.filter { it.isNotEmpty() }

        val scored = ArrayList<Pair<Int, ContactHit>>()
        val cursor = context.contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
            null, null, null
        ) ?: return emptyList()

        cursor.use { c ->
            val iName = c.getColumnIndexOrThrow(Phone.DISPLAY_NAME)
            val iNum = c.getColumnIndexOrThrow(Phone.NUMBER)
            while (c.moveToNext()) {
                val name = c.getString(iName) ?: continue
                val number = c.getString(iNum) ?: continue
                val s = score(name, q, qKey, qTokKeys)
                if (s >= 70) scored.add(Pair(s, ContactHit(name, number)))
            }
        }

        if (scored.isEmpty()) return emptyList()
        val top = scored.maxOf { it.first }
        return scored.filter { it.first == top }
            .map { it.second }
            .distinctBy { it.name.lowercase() }
    }

    private fun score(name: String, q: String, qKey: String, qTokKeys: List<String>): Int {
        val n = Phonetic.clean(name)
        if (n.isEmpty()) return 0
        if (n == q) return 120

        val nKey = Phonetic.key(name)
        if (nKey.isNotEmpty() && nKey == qKey) return 110

        val nTokens = n.split(" ")
        if (nTokens.contains(q)) return 100

        val nTokKeys = nTokens.map { Phonetic.key(it) }.filter { it.isNotEmpty() }
        if (qTokKeys.isNotEmpty() && qTokKeys.all { it in nTokKeys }) return 90

        if (q.length >= 3 && n.contains(q)) return 80
        if (qKey.length >= 3 && nKey.startsWith(qKey)) return 75
        if (qKey.length >= 3 && nKey.contains(qKey)) return 70
        return 0
    }
}
