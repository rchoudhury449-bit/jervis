package com.rahul.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Baat-cheet ke liye Google Gemini API.
 * API key sirf phone me save hoti hai (app ki screen se), code me kahin nahi.
 * ask() network use karta hai, isliye hamesha background thread se bulao.
 */
object GeminiChat {

    const val ERR_KEY = "key"
    const val ERR_MODEL = "model"
    const val ERR_LIMIT = "limit"
    const val ERR_NET = "net"
    const val ERR_OTHER = "other"

    data class Reply(val text: String?, val error: String?)

    private const val MAX_HISTORY = 10
    private val history = ArrayList<Pair<String, String>>() // (role, text)

    fun clear() {
        synchronized(history) { history.clear() }
    }

    private fun systemPrompt(hindi: Boolean, address: String): String {
        val addrRule = if (address.isBlank()) "" else {
            "यूज़र तुम्हारा मालिक है। उसे '${address}' कहकर संबोधित करो, लेकिन पूरे जवाब में ज़्यादा से ज़्यादा एक बार, हर वाक्य में नहीं। " +
                "सिर्फ़ 'जी ${address}' या 'ठीक है ${address}' कहकर कभी मत रुकना: पहले सवाल का असली जवाब दो। "
        }
        val script = if (hindi) {
            "जवाब हिंदी (देवनागरी) में दो; ज़रूरी अंग्रेज़ी शब्द बीच में आ सकते हैं।"
        } else {
            "Reply in simple Hinglish or English using Roman letters."
        }
        return "तुम एक पेशेवर निजी असिस्टेंट हो: विनम्र, भरोसेमंद, सटीक और सीधे मुद्दे पर बोलने वाले। " +
            "यूज़र जो पूछे, उसका पूरा और काम का जवाब दो; सवाल को टालो मत और सिर्फ़ हामी भरकर मत छोड़ो। " +
            script + " " + addrRule +
            "तुम्हारा जवाब बोलकर सुनाया जाएगा, इसलिए 2 से 4 छोटे वाक्य बोलो। कोई लिस्ट, markdown, तारे, हैशटैग या emoji नहीं। " +
            "लहजा आदर वाला और गर्मजोश रखो; मज़ाक या 'यार' जैसे अनौपचारिक शब्द मत इस्तेमाल करो। " +
            "जो बात पक्की पता न हो उसे अंदाज़े से मत बताओ; साफ़ कहो कि पक्का पता नहीं। " +
            "ज़रूरत हो तो नरमी से सच या असहमति बताओ; सिर्फ़ हाँ में हाँ मत मिलाओ। खतरे या सेहत की बात पर टोकना मत छोड़ो। " +
            "यूज़र बाइक चला रहा हो सकता है, इसलिए जवाब छोटा रखो और ऐसा कुछ मत कहो जिसमें स्क्रीन देखनी पड़े। " +
            "सेहत, कानून या पैसे के गंभीर मामलों में सही जानकारी दो और ज़रूरत हो तो जानकार से मिलने को कहो। " +
            "कोई पूछे कि तुम इंसान हो या AI, तो सच बताओ कि तुम AI हो। " +
            "कॉल, मैप्स और म्यूज़िक के आदेश ऐप खुद संभालता है; यहाँ सिर्फ़ बातचीत और सवालों का जवाब दो।"
    }

    private fun sanitize(s: String): String {
        return s.replace(Regex("[*#_`~]"), "")
            .replace(Regex("[\\uD800-\\uDFFF]"), "") // emoji hatao, TTS unhe padhta hai
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun ask(apiKey: String, modelName: String, userText: String, hindi: Boolean, address: String): Reply {
        var conn: HttpURLConnection? = null
        try {
            val m = modelName.trim().removePrefix("models/").ifEmpty { AssistantService.DEFAULT_MODEL }
            val url = URL(
                "https://generativelanguage.googleapis.com/v1beta/models/" + m +
                    ":generateContent?key=" + URLEncoder.encode(apiKey.trim(), "UTF-8")
            )

            val contents = JSONArray()
            val snapshot = synchronized(history) { ArrayList(history) }
            for ((role, text) in snapshot) contents.put(turn(role, text))
            contents.put(turn("user", userText))

            val body = JSONObject()
                .put(
                    "system_instruction",
                    JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt(hindi, address))))
                )
                .put("contents", contents)
                .put(
                    "generationConfig",
                    JSONObject().put("temperature", 0.7).put("maxOutputTokens", 2048)
                )

            conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 25_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

            if (code !in 200..299) {
                val err = when {
                    code == 401 || code == 403 -> ERR_KEY
                    code == 400 && resp.contains("API key", ignoreCase = true) -> ERR_KEY
                    code == 404 -> ERR_MODEL
                    code == 429 -> ERR_LIMIT
                    else -> ERR_OTHER
                }
                return Reply(null, err)
            }

            val cands = JSONObject(resp).optJSONArray("candidates")
            if (cands == null || cands.length() == 0) return Reply(null, ERR_OTHER)
            val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.optBoolean("thought", false)) continue
                    sb.append(p.optString("text", ""))
                }
            }
            val reply = sanitize(sb.toString())
            if (reply.isEmpty()) return Reply(null, ERR_OTHER)

            synchronized(history) {
                history.add(Pair("user", userText))
                history.add(Pair("model", reply))
                while (history.size > MAX_HISTORY) history.removeAt(0)
            }
            return Reply(reply, null)
        } catch (e: IOException) {
            return Reply(null, ERR_NET)
        } catch (e: Exception) {
            return Reply(null, ERR_OTHER)
        } finally {
            conn?.disconnect()
        }
    }

    private fun turn(role: String, text: String): JSONObject =
        JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))
}
